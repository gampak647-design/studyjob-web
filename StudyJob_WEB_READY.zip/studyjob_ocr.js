(() => {
  let workerPromise = null;
  let queue = Promise.resolve();

  async function getWorker() {
    if (!globalThis.Tesseract || typeof globalThis.Tesseract.createWorker !== 'function') {
      throw new Error('tesseract_not_loaded');
    }
    if (!workerPromise) {
      workerPromise = globalThis.Tesseract.createWorker('rus', 1, {
        logger: () => {},
      });
    }
    return workerPromise;
  }

  async function recognizeInternal(imageUrl) {
    const value = String(imageUrl || '').trim();
    if (!value) {
      return JSON.stringify({
        available: false,
        text: '',
        confidence: null,
        engine: 'web_tesseract_v5_ru',
        error: 'empty_image_url',
      });
    }

    try {
      const worker = await getWorker();
      const result = await worker.recognize(value, { rotateAuto: true });
      const data = result && result.data ? result.data : {};
      const text = String(data.text || '').trim();
      const confidenceRaw = Number(data.confidence);
      const confidence = Number.isFinite(confidenceRaw)
        ? Math.max(0, Math.min(100, Math.round(confidenceRaw)))
        : null;
      return JSON.stringify({
        available: text.length > 0,
        text,
        confidence,
        engine: 'web_tesseract_v5_ru',
        error: text.length > 0 ? null : 'empty_ocr_text',
      });
    } catch (error) {
      return JSON.stringify({
        available: false,
        text: '',
        confidence: null,
        engine: 'web_tesseract_v5_ru',
        error: 'web_ocr_failed',
      });
    }
  }

  function pickImageInternal(source) {
    return new Promise((resolve) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/jpeg,image/png,image/webp';
      input.style.position = 'fixed';
      input.style.left = '-10000px';
      input.style.top = '-10000px';
      if (String(source || '') === 'camera') {
        input.setAttribute('capture', 'environment');
      }

      let settled = false;
      const finish = (payload) => {
        if (settled) return;
        settled = true;
        try {
          input.remove();
        } catch (_) {}
        resolve(JSON.stringify(payload));
      };

      input.addEventListener('change', () => {
        const file = input.files && input.files.length > 0 ? input.files[0] : null;
        if (!file) {
          finish({ cancelled: true });
          return;
        }

        const mime = String(file.type || '').toLowerCase();
        if (!['image/jpeg', 'image/png', 'image/webp'].includes(mime)) {
          finish({ cancelled: false, error: 'unsupported_image' });
          return;
        }

        const reader = new FileReader();
        reader.onload = () => {
          const dataUrl = String(reader.result || '');
          if (!dataUrl.startsWith('data:image/')) {
            finish({ cancelled: false, error: 'file_read_failed' });
            return;
          }
          finish({
            cancelled: false,
            data_url: dataUrl,
            mime,
            name: String(file.name || 'verification-image'),
            size: Number(file.size || 0),
          });
        };
        reader.onerror = () => finish({ cancelled: false, error: 'file_read_failed' });
        reader.readAsDataURL(file);
      });

      document.body.appendChild(input);
      input.click();
    });
  }

  globalThis.StudyJobOcr = {
    recognize(imageUrl) {
      queue = queue.catch(() => {}).then(() => recognizeInternal(imageUrl));
      return queue;
    },
    pickImage(source) {
      return pickImageInternal(source);
    },
  };
})();
