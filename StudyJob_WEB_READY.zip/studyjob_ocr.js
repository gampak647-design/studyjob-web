(() => {
  let workerPromise = null;
  let queue = Promise.resolve();

  async function getWorker() {
    if (!globalThis.Tesseract || typeof globalThis.Tesseract.createWorker !== 'function') {
      throw new Error('tesseract_not_loaded');
    }
    if (!workerPromise) {
      workerPromise = globalThis.Tesseract.createWorker('rus', 1, {
        logger: () => {},
      });
    }
    return workerPromise;
  }

  async function recognizeInternal(imageUrl) {
    const value = String(imageUrl || '').trim();
    if (!value) {
      return JSON.stringify({
        available: false,
        text: '',
        confidence: null,
        engine: 'web_tesseract_v5_ru',
        error: 'empty_image_url',
      });
    }

    try {
      const worker = await getWorker();
      const result = await worker.recognize(value, { rotateAuto: true });
      const data = result && result.data ? result.data : {};
      const text = String(data.text || '').trim();
      const confidenceRaw = Number(data.confidence);
      const confidence = Number.isFinite(confidenceRaw)
        ? Math.max(0, Math.min(100, Math.round(confidenceRaw)))
        : null;
      return JSON.stringify({
        available: text.length > 0,
        text,
        confidence,
        engine: 'web_tesseract_v5_ru',
        error: text.length > 0 ? null : 'empty_ocr_text',
      });
    } catch (error) {
      return JSON.stringify({
        available: false,
        text: '',
        confidence: null,
        engine: 'web_tesseract_v5_ru',
        error: 'web_ocr_failed',
      });
    }
  }

  globalThis.StudyJobOcr = {
    recognize(imageUrl) {
      queue = queue.catch(() => {}).then(() => recognizeInternal(imageUrl));
      return queue;
    },
  };
})();
