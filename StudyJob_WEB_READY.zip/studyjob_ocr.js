(() => {
  let workerPromise = null;
  let queue = Promise.resolve();
  let pickerSequence = 0;
  let rememberedOcrToken = '';
  let rememberedOcrDataUrl = '';

  async function getWorker() {
    if (!globalThis.Tesseract || typeof globalThis.Tesseract.createWorker !== 'function') {
      throw new Error('tesseract_not_loaded');
    }
    if (!workerPromise) {
      workerPromise = (async () => {
        const worker = await globalThis.Tesseract.createWorker('rus', 1, {
          logger: () => {},
        });
        try {
          if (worker && typeof worker.setParameters === 'function') {
            await worker.setParameters({
              tessedit_pageseg_mode: '11',
              preserve_interword_spaces: '1',
              user_defined_dpi: '300',
            });
          }
        } catch (_) {}
        return worker;
      })();
    }
    return workerPromise;
  }

  function rememberOcrDataUrl(dataUrl) {
    pickerSequence += 1;
    rememberedOcrToken = `${Date.now().toString(36)}_${pickerSequence.toString(36)}`;
    rememberedOcrDataUrl = dataUrl;
    return rememberedOcrToken;
  }

  function resolveOcrSource(imageSource) {
    const value = String(imageSource || '').trim();
    const prefix = 'studyjob-picker:';
    if (!value.startsWith(prefix)) return value;
    const token = value.slice(prefix.length);
    if (!token || token !== rememberedOcrToken || !rememberedOcrDataUrl) {
      throw new Error('picker_image_expired');
    }
    return rememberedOcrDataUrl;
  }

  async function recognizeInternal(imageSource) {
    let value = '';
    try {
      value = resolveOcrSource(imageSource);
    } catch (_) {
      return JSON.stringify({
        available: false,
        text: '',
        confidence: null,
        engine: 'web_tesseract_v5_ru_psm11',
        error: 'picker_image_expired',
      });
    }

    if (!value) {
      return JSON.stringify({
        available: false,
        text: '',
        confidence: null,
        engine: 'web_tesseract_v5_ru_psm11',
        error: 'empty_image_url',
      });
    }

    try {
      const worker = await getWorker();
      const result = await worker.recognize(value, { rotateAuto: true });
      const data = result && result.data ? result.data : {};
      const text = String(data.text || '').trim();
      const confidenceRaw = Number(data.confidence);
      const confidence = Number.isFinite(confidenceRaw)
        ? Math.max(0, Math.min(100, Math.round(confidenceRaw)))
        : null;
      return JSON.stringify({
        available: text.length > 0,
        text,
        confidence,
        engine: 'web_tesseract_v5_ru_psm11',
        error: text.length > 0 ? null : 'empty_ocr_text',
      });
    } catch (_) {
      return JSON.stringify({
        available: false,
        text: '',
        confidence: null,
        engine: 'web_tesseract_v5_ru_psm11',
        error: 'web_ocr_failed',
      });
    }
  }

  function bytesToBase64(bytes) {
    const chunkSize = 0x8000;
    let binary = '';
    for (let offset = 0; offset < bytes.length; offset += chunkSize) {
      const chunk = bytes.subarray(
        offset,
        Math.min(offset + chunkSize, bytes.length),
      );
      binary += String.fromCharCode(...chunk);
    }
    return btoa(binary);
  }

  async function readFileAsDataUrl(file, mime) {
    let buffer;
    if (file && typeof file.arrayBuffer === 'function') {
      buffer = await file.arrayBuffer();
    } else if (typeof Response === 'function') {
      buffer = await new Response(file).arrayBuffer();
    } else {
      throw new Error('array_buffer_unavailable');
    }

    const bytes = new Uint8Array(buffer);
    if (bytes.length === 0) throw new Error('empty_file');
    return `data:${mime};base64,${bytesToBase64(bytes)}`;
  }

  async function decodeImageFile(file) {
    if (typeof globalThis.createImageBitmap === 'function') {
      try {
        const bitmap = await globalThis.createImageBitmap(file, {
          imageOrientation: 'from-image',
        });
        return {
          source: bitmap,
          width: bitmap.width,
          height: bitmap.height,
          dispose() {
            try { bitmap.close(); } catch (_) {}
          },
        };
      } catch (_) {
        try {
          const bitmap = await globalThis.createImageBitmap(file);
          return {
            source: bitmap,
            width: bitmap.width,
            height: bitmap.height,
            dispose() {
              try { bitmap.close(); } catch (_) {}
            },
          };
        } catch (_) {}
      }
    }

    if (!globalThis.URL || typeof globalThis.URL.createObjectURL !== 'function') {
      throw new Error('image_decode_unavailable');
    }

    const url = globalThis.URL.createObjectURL(file);
    try {
      const image = new Image();
      image.decoding = 'async';
      await new Promise((resolve, reject) => {
        image.onload = () => resolve();
        image.onerror = () => reject(new Error('image_decode_failed'));
        image.src = url;
      });
      return {
        source: image,
        width: image.naturalWidth || image.width,
        height: image.naturalHeight || image.height,
        dispose() {
          try { globalThis.URL.revokeObjectURL(url); } catch (_) {}
        },
      };
    } catch (error) {
      try { globalThis.URL.revokeObjectURL(url); } catch (_) {}
      throw error;
    }
  }

  function createCanvas(width, height) {
    const canvas = document.createElement('canvas');
    canvas.width = width;
    canvas.height = height;
    const context = canvas.getContext('2d');
    if (!context) throw new Error('canvas_unavailable');
    context.imageSmoothingEnabled = true;
    try { context.imageSmoothingQuality = 'high'; } catch (_) {}
    return { canvas, context };
  }

  function canvasDataUrl(canvas, quality) {
    const dataUrl = canvas.toDataURL('image/jpeg', quality);
    if (!String(dataUrl || '').startsWith('data:image/jpeg;base64,')) {
      throw new Error('canvas_encode_failed');
    }
    return dataUrl;
  }

  async function preparePickedImage(file, mime) {
    let decoded = null;
    try {
      decoded = await decodeImageFile(file);
      const width = Number(decoded.width || 0);
      const height = Number(decoded.height || 0);
      if (width < 16 || height < 16) throw new Error('image_dimensions_invalid');

      const maxDimension = 2560;
      const scale = Math.min(1, maxDimension / Math.max(width, height));
      const targetWidth = Math.max(1, Math.round(width * scale));
      const targetHeight = Math.max(1, Math.round(height * scale));

      const upload = createCanvas(targetWidth, targetHeight);
      upload.context.fillStyle = '#ffffff';
      upload.context.fillRect(0, 0, targetWidth, targetHeight);
      upload.context.drawImage(decoded.source, 0, 0, targetWidth, targetHeight);

      const uploadDataUrl = canvasDataUrl(upload.canvas, 0.88);
      const ocrDataUrl = canvasDataUrl(upload.canvas, 0.94);

      return {
        uploadDataUrl,
        ocrDataUrl,
        mime: 'image/jpeg',
      };
    } catch (_) {
      const dataUrl = await readFileAsDataUrl(file, mime);
      return {
        uploadDataUrl: dataUrl,
        ocrDataUrl: dataUrl,
        mime,
      };
    } finally {
      if (decoded) decoded.dispose();
    }
  }

  function pickImageInternal(source) {
    return new Promise((resolve) => {
      const input = document.createElement('input');
      input.type = 'file';
      input.accept = 'image/jpeg,image/png,image/webp';
      input.style.position = 'fixed';
      input.style.left = '-10000px';
      input.style.top = '-10000px';
      if (String(source || '') === 'camera') {
        input.setAttribute('capture', 'environment');
      }

      let settled = false;
      const finish = (payload) => {
        if (settled) return;
        settled = true;
        try { input.remove(); } catch (_) {}
        resolve(JSON.stringify(payload));
      };

      input.addEventListener('change', () => {
        const file = input.files && input.files.length > 0 ? input.files[0] : null;
        if (!file) {
          finish({ cancelled: true });
          return;
        }

        const mime = String(file.type || '').toLowerCase();
        if (!['image/jpeg', 'image/png', 'image/webp'].includes(mime)) {
          finish({ cancelled: false, error: 'unsupported_image' });
          return;
        }

        void (async () => {
          try {
            const prepared = await preparePickedImage(file, mime);
            const token = rememberOcrDataUrl(prepared.ocrDataUrl);
            finish({
              cancelled: false,
              data_url: prepared.uploadDataUrl,
              mime: prepared.mime,
              name: String(file.name || 'verification-image'),
              size: Number(file.size || 0),
              ocr_token: token,
            });
          } catch (error) {
            const detail = String(
              error && error.message ? error.message : error || 'unknown',
            );
            finish({
              cancelled: false,
              error: `file_prepare_failed:${detail}`,
            });
          }
        })();
      });

      document.body.appendChild(input);
      input.click();
    });
  }

  globalThis.StudyJobOcr = {
    recognize(imageSource) {
      queue = queue.catch(() => {}).then(() => recognizeInternal(imageSource));
      return queue;
    },
    pickImage(source) {
      return pickImageInternal(source);
    },
  };
})();
