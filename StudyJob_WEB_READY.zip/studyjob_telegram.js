// Study Job Telegram Mini App bridge.
// This file deliberately exposes only the raw Telegram initData string to Dart.
// Authorization decisions must be made server-side after validating initData.
(function () {
  'use strict';

  const telegram = window.Telegram && window.Telegram.WebApp
    ? window.Telegram.WebApp
    : null;

  function isMiniApp() {
    return Boolean(telegram && typeof telegram.initData === 'string' && telegram.initData.length > 0);
  }

  function safeString(value) {
    return typeof value === 'string' ? value : '';
  }

  async function requestWriteAccess() {
    if (!telegram || typeof telegram.requestWriteAccess !== 'function') return false;
    return await new Promise(function (resolve) {
      try {
        telegram.requestWriteAccess(function (granted) {
          resolve(granted === true);
        });
      } catch (_) {
        resolve(false);
      }
    });
  }

  function openTelegramLink(url) {
    if (!telegram || typeof telegram.openTelegramLink !== 'function') return false;
    if (typeof url !== 'string' || !url.startsWith('https://t.me/')) return false;
    telegram.openTelegramLink(url);
    return true;
  }

  window.StudyJobTelegram = Object.freeze({
    isMiniApp: isMiniApp,
    getInitData: function () {
      return telegram ? safeString(telegram.initData) : '';
    },
    getPlatform: function () {
      return telegram ? safeString(telegram.platform) : '';
    },
    getColorScheme: function () {
      return telegram ? safeString(telegram.colorScheme) : '';
    },
    getStartParam: function () {
      if (!telegram || !telegram.initDataUnsafe) return '';
      return safeString(telegram.initDataUnsafe.start_param);
    },
    requestWriteAccess: requestWriteAccess,
    openTelegramLink: openTelegramLink,
  });

  if (telegram) {
    try {
      telegram.ready();
      telegram.expand();
    } catch (_) {
      // Keep normal Flutter Web startup working outside supported Telegram clients.
    }
  }

  window.dispatchEvent(new CustomEvent('studyjob-telegram-ready', {
    detail: { available: isMiniApp() },
  }));
})();
